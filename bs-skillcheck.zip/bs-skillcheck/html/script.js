const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let angle = 0;
let speed = 0.03 * 0.4; 
let direction = 1;
let targetAngle = Math.random() * Math.PI * 2;
let targetSize = Math.PI / 25 * 4.3875; 
let playing = false;
let udaneCount = 0;
const maxudane = 4;
const SCALE = 0.455; 

window.addEventListener("message", function (event) {
  if (event.data.action === "open") {
    playing = true;
    udaneCount = 0;
    resetTarget();
    loop();
  } else if (event.data.action === "close") {
    playing = false;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }
});

function resetTarget() {
  targetAngle = Math.random() * Math.PI * 2;
}

function loop() {
  if (!playing) return;
  update();
  draw();
  requestAnimationFrame(loop);
}

function update() {
  angle += speed * direction;
  if (angle > Math.PI * 2) angle -= Math.PI * 2;
  if (angle < 0) angle += Math.PI * 2;
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.save();
  ctx.translate(canvas.width / 2, canvas.height / 2);
  ctx.scale(SCALE, SCALE);

  let radius = 150;

  ctx.beginPath();
  ctx.arc(0, 0, radius, 0, Math.PI * 2);
  ctx.strokeStyle = "#252525ff";
  ctx.lineWidth = 8;
  ctx.stroke();

  ctx.beginPath();
  ctx.arc(0, 0, radius, targetAngle - targetSize * 0.3, targetAngle + targetSize + targetSize * 0.3);
  ctx.strokeStyle = "#1e8fffff";
  ctx.lineWidth = 12;
  ctx.stroke();

  ctx.beginPath();
  ctx.moveTo(Math.cos(angle) * (radius * 0.63), Math.sin(angle) * (radius * 0.63));
  ctx.lineTo(Math.cos(angle) * radius, Math.sin(angle) * radius);
  ctx.strokeStyle = "white";
  ctx.lineWidth = 4;
  ctx.stroke();

  let rectW = 68;
  let rectH = 68;
  ctx.fillStyle = "#429efaa1";
  roundRect(ctx, -rectW/2, -rectH/2, rectW, rectH, 12, true, false);
  ctx.fillStyle = "white";
  ctx.font = "bold 42px Arial";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText("E", 0, 0);

  ctx.restore();
}

function roundRect(ctx, x, y, width, height, radius, fill, stroke) {
  if (typeof radius === "undefined") radius = 5;
  if (typeof radius === "number") {
    radius = { tl: radius, tr: radius, br: radius, bl: radius };
  } else {
    var defaultRadius = { tl: 0, tr: 0, br: 0, bl: 0 };
    for (var side in defaultRadius) {
      radius[side] = radius[side] || defaultRadius[side];
    }
  }
  ctx.beginPath();
  ctx.moveTo(x + radius.tl, y);
  ctx.lineTo(x + width - radius.tr, y);
  ctx.quadraticCurveTo(x + width, y, x + width, y + radius.tr);
  ctx.lineTo(x + width, y + height - radius.br);
  ctx.quadraticCurveTo(x + width, y + height, x + width - radius.br, y + height);
  ctx.lineTo(x + radius.bl, y + height);
  ctx.quadraticCurveTo(x, y + height, x, y + height - radius.bl);
  ctx.lineTo(x, y + radius.tl);
  ctx.quadraticCurveTo(x, y, x + radius.tl, y);
  ctx.closePath();
  if (fill) ctx.fill();
  if (stroke) ctx.stroke();
}

function closeUI(udane) {
  fetch(`https://${GetParentResourceName()}/${udane ? "udane" : "nieudane"}`, {
    method: "POST",
    body: "{}"
  });
  fetch(`https://${GetParentResourceName()}/close`, {method: "POST", body: "{}"});
  playing = false;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
}

document.addEventListener("keydown", function (e) {
  if (!playing) return;
  if (e.key === "e" || e.key === "E") {
    if (angle > targetAngle && angle < targetAngle + targetSize) {
      udaneCount++;
      if (udaneCount >= maxudane) {
        closeUI(true);
      } else {
        resetTarget();
        direction *= -1;
      }
    } else {
      closeUI(false);
    }
  }
});
