local skillOpen = false
local skillCallback = nil
local currentAnim = nil

function openSkillcheck(cb, animData)
    if skillOpen then return end
    skillOpen = true
    skillCallback = cb
    currentAnim = animData

    if currentAnim then
        playAnimation(currentAnim)
    end

    SetNuiFocus(true, true)
    SendNUIMessage({ action = "open" })
end

function zamknijskill()
    if not skillOpen then return end
    skillOpen = false
    skillCallback = nil
    currentAnim = nil

    ClearPedTasksImmediately(PlayerPedId())
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "close" })
end

RegisterNUICallback("udane", function(_, cb)
    if skillCallback then
        skillCallback(true)
        TriggerEvent("skillcheck:result", true)
    end
    zamknijskill()
    cb("ok")
end)

RegisterNUICallback("nieudane", function(_, cb)
    if skillCallback then
        skillCallback(false)
        TriggerEvent("skillcheck:result", false)
    end
    zamknijskill()
    cb("ok")
end)

RegisterNUICallback("close", function(_, cb)
    zamknijskill()
    cb("ok")
end)

function playAnimation(animData)
    local ped = animData.ped or PlayerPedId()

    RequestAnimDict(animData.dict)
    while not HasAnimDictLoaded(animData.dict) do
        Wait(0)
    end

    TaskPlayAnim(
        ped,
        animData.dict,
        animData.clip,
        3.0,
        -1.0,
        animData.duration or -1,
        animData.flag or 49,
        0.0,
        false,
        false,
        false
    )
end