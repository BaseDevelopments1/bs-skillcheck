local skillOpen = false
local skillCallback = nil
local currentAnim = nil

function openSkillcheck(difficulty, timeLimitMs, cb, anim)
    if skillOpen then return end
    skillOpen = true
    skillCallback = cb 
    if type(anim) == "table" and anim.dict and anim.clip then
        currentAnim = anim
        playAnimation(currentAnim)
    else
        currentAnim = nil
    end
    SetNuiFocus(true, false)
    SendNUIMessage({
        action = "open",
        difficulty = math.max(1, math.min(5, tonumber(difficulty) or 2)),
        timeLimit = tonumber(timeLimitMs) or 8000
    })
end

function zamknijskill()
    if not skillOpen then return end
    skillOpen = false
    skillCallback = nil
    currentAnim = nil

    ClearPedTasksImmediately(PlayerPedId())
    SetNuiFocus(false, false)
    SendNUIMessage({ action = "close" })
end

RegisterNUICallback("udane", function(_, cb)
    if skillCallback then
        skillCallback(true, { reason = "ok" })
        TriggerEvent("skillcheck:result", true)
    end
    zamknijskill()
    cb("ok")
end)

RegisterNUICallback("nieudane", function(_, cb)
    if skillCallback then
        skillCallback(false, { reason = "fail" })
        TriggerEvent("skillcheck:result", false)
    end
    zamknijskill()
    cb("ok")
end)

RegisterNUICallback("close", function(_, cb)
    zamknijskill()
    cb("ok")
end)

function playAnimation(animData)
    local ped = animData.ped or PlayerPedId()

    RequestAnimDict(animData.dict)
    while not HasAnimDictLoaded(animData.dict) do
        Wait(0)
    end

    TaskPlayAnim(
        ped,
        animData.dict,
        animData.clip,     
        3.0,
        -1.0,
        animData.duration or -1,
        animData.flag or 49,
        0.0,
        false,
        false,
        false
    )
end
